package com.rolleaserental.config;

import com.rolleaserental.entities.Product;

public interface ProductService {

    Product getProductById(Integer productId);
}