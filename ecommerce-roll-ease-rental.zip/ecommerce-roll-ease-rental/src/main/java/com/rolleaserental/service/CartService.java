package com.rolleaserental.service;

import com.rolleaserental.entities.CartItem;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {
    private HttpSession httpSession; // Assuming you're using session management

    public CartService(HttpSession httpSession) {
        this.httpSession = httpSession;
    }

    public void addItemsToCart(List<CartItem> cartItems) {
        // Retrieve existing cart (or create an empty one if not present)
        List<CartItem> existingCart = (List<CartItem>) httpSession.getAttribute("cart");
        if (existingCart == null) {
            existingCart = new ArrayList<>();
        }

        for (CartItem item : cartItems) {
            existingCart.add(item);

            Boolean isRentValue = item.isRent();
            System.out.println("isRentValue for item: "+item.getProductId()+ " is : "+isRentValue);
        }
        // Update the cart session attribute with the modified cart
        httpSession.setAttribute("cart", existingCart);
    }

    public List<CartItem> getAllCartItems(){
        List<CartItem> existingCart = (List<CartItem>) httpSession.getAttribute("cart");
        return existingCart;
    }
}
