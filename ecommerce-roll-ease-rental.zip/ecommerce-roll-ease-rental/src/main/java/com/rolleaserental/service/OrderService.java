package com.rolleaserental.service;

import com.rolleaserental.daos.OrderRepository;
import com.rolleaserental.daos.UserRepository;
import com.rolleaserental.entities.Order;
import com.rolleaserental.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository; // Assuming you have a repository for orders

    @Autowired
    private EmailService emailService;
    @Autowired
    private UserRepository userRepository;


    public Order processOrder(Long userId, String pincode, String address) {
        User user = userRepository.findById(userId.intValue()).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        Order orderDetails = new Order();
        orderDetails.setUser(user);
        orderDetails.setPincode(pincode);
        orderDetails.setAddress(address);

        orderRepository.save(orderDetails);

        return orderDetails;
    }

    public List<Order> findOrdersByUsername(String username) {
        List<Order> orders = orderRepository.findByUsername(username);
        System.out.println("Orders for username " + username + ": " + orders);
        return orderRepository.findByUsername(username);
    }
}
