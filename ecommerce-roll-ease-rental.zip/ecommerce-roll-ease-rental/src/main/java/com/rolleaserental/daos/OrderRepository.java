package com.rolleaserental.daos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rolleaserental.entities.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	@Query(value = "select * from orders where product_id = ?", nativeQuery = true)
	Optional<Order> findByProductId(@Param("id") Integer id);

	@Query(value = "select * from orders where id = :id", nativeQuery = true)
	public Optional<Order> findById(@Param("id") Long id); // Return Optional<Order>

	@Query(value = "select * from orders where username = :username",nativeQuery = true)
	List<Order> findByUsername(@Param("username") String username);
    List<Order> findAllById(int id);

	List<Order> findByUser(int id);

	List<Order> findByUserId(int id);
}
