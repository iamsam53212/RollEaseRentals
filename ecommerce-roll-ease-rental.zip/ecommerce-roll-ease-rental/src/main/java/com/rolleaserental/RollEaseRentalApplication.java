package com.rolleaserental;

import com.rolleaserental.daos.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.rolleaserental.daos.UserRepository;
import com.rolleaserental.entities.User;

import java.util.Date;


@SpringBootApplication
@ComponentScan(basePackages = "com.rolleaserental.*")
public class RollEaseRentalApplication implements CommandLineRunner {
	
	@Autowired
	public BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ProductRepository productRepository;

	public static void main(String[] args) {
		SpringApplication.run(RollEaseRentalApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
//		User user = new User();
//
//
//		user.setId(1);
//		user.setEmail("admin@wheelchairwaala.com");
//		user.setEnable(true);
//		user.setName("Sameer Khowaja");
//		user.setPhone("03343876328");
//		user.setRole("ROLE_ADMIN");
//		user.setPassword(passwordEncoder.encode("admin@123"));
//		user.setProfile("admin.png");
//		user.setDate(new Date());
//
//		this.userRepo.save(user);

		
		
	}


}
