/* This is Main Controller, here are every view that related to public url. */

package com.rolleaserental.controllers;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.time.LocalDate;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.rolleaserental.config.ProductService;
import com.rolleaserental.entities.*;
import com.rolleaserental.service.CartService;
import com.rolleaserental.service.EmailService;
import com.rolleaserental.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rolleaserental.daos.CategoryRepository;
import com.rolleaserental.daos.CommentRepository;
import com.rolleaserental.daos.OrderRepository;
import com.rolleaserental.daos.ProductRepository;
import com.rolleaserental.daos.UnbanRequestRepository;
import com.rolleaserental.daos.UserRepository;

@Controller
public class MainController {

	/* Autowired */

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private OrderRepository orderRepo;

	@Autowired
	private CategoryRepository categoryRepo;

	@Autowired
	private ProductRepository productRepo;

	@Autowired
	private UnbanRequestRepository unbanRequestRepo;

	@Autowired
	private CommentRepository commentRepo;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private EmailService emailService;

	@Autowired
	private OrderService orderService;

	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;


	/* ==================== */

	// home page view.

	@GetMapping(value = { "/", "/home" })
	public String firstHomeView(Model m, Principal principal) {
		if (principal != null) {
			m.addAttribute("user", this.userRepo.loadUserByUserName(principal.getName()));
		}

		List<Product> products = this.productRepo.getProducts();
		List<Category> categories = categoryRepo.findAll();

		m.addAttribute("title", "Roll Ease Rental");
		m.addAttribute("categories", categories);
		m.addAttribute("products", products);
		return "index.html";
	}

       /* Register page view */
	@GetMapping("/register")
	public String registerPage(Model m) {

		m.addAttribute("title", "Register | Roll Ease Rental");
		m.addAttribute("user", new User());
		return "register";
	}

	@GetMapping("/about")
	public String aboutPage(Model m) {
		m.addAttribute("title", "About Us | Roll Ease Rental");
		return "about";
	}

	@GetMapping("/contact")
	public String contactPage(Model m) {
		m.addAttribute("title", "Contact Us | Roll Ease Rental");
		m.addAttribute("unbanRequest", new UnbanRequest());
		return "contact";
	}


	@PostMapping("/process-registration")
	public String doRegister(@Valid @ModelAttribute("user") User user, BindingResult result, RedirectAttributes redir,
			@RequestParam("confirm_password") String confirmPassword, @RequestParam("user_role") String role, Model m,
			HttpSession httpSession) {

		if (result.hasErrors()) {
			m.addAttribute("user", user);
			return "register";
		}

		if (role.equals("non-selected")) {
			m.addAttribute("user", user);
			httpSession.setAttribute("status", "role-not-select");
			return "redirect:/register";
		}

		if (confirmPassword.equals("") || confirmPassword == null) {
			m.addAttribute("user", user);
			httpSession.setAttribute("status", "cp-empty");
			return "redirect:/register";
		}

		if (!user.getPassword().equals(confirmPassword)) {
			m.addAttribute("user", user);
			httpSession.setAttribute("status", "cp-not-match");
			return "redirect:/register";
		}

		try {
			user.setRole(role.equals("customer") ? "ROLE_CUSTOMER" : "ROLE_SELLER");

			user.setEnable(true);
			user.setProfile("user.png");
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			user.setDate(new Date());

			this.userRepo.save(user);

		} catch (DataIntegrityViolationException e) {
			httpSession.setAttribute("status", "email-exist");
			m.addAttribute("user", user);
			return "redirect:/register";

		} catch (Exception e) {
			httpSession.setAttribute("status", "went-wrong");
			e.printStackTrace();
		}

		httpSession.setAttribute("status", "registered-success");
		return "redirect:/register";
	}

	@GetMapping("/login")
	public String loginPage(Model m) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (!(auth instanceof AnonymousAuthenticationToken)) {

			User user = this.userRepo.loadUserByUserName(auth.getName());

			if (user.getRole().equals("ROLE_CUSTOMER")) {
				return "redirect:/home";
			}
			if (user.getRole().equals("ROLE_ADMIN")) {
				return "redirect:/admin/home";
			}
			if (user.getRole().equals("ROLE_SELLER")) {
				return "redirect:/seller/home";
			}

		}

		m.addAttribute("title", "Login | Roll Ease Rental");
		return "login";
	}

	/*
	 * The above function is a method that handles requests to the /login URL. If
	 * the user is logged in, the function redirects them to a different URL
	 * depending on their role (e.g. /customer/home, /admin/home, or /seller/home).
	 * If the user is not logged in, the function adds an attribute to the Model
	 * object and returns a view that will likely render a login page for the user.
	 */

	@GetMapping("/search")
	public String searchProductsByCategory(@RequestParam(value = "category",required = false) Integer categoryId, Model model) {
		List<Product> products;
		if (categoryId != null) {
			products = productRepo.findByCategory(categoryRepo.findById(categoryId).get());
		} else {
			products = productRepo.findAll(); // Show all products if no category selected
		}
		model.addAttribute("products", products);
		model.addAttribute("selectedCategoryId", categoryId); // Optional for pre-selecting category in view
		return "index.html"; // View name
	}

	/*
	 *                         EXPLANATION OF SEARCH METHOD
	 *
	 *  the above function is a method that handles request to the /search URL.
	 *  it displays all of the products related to the query and category.
	 */

	@PostMapping("/profile/action")
	public String updateProfile(@ModelAttribute("user") User user, BindingResult result, Model model,
								@RequestParam(value = "profile_image", required = false) MultipartFile profileImage,
								HttpSession session, Principal principal) {

		User loggedInUser = this.userRepo.loadUserByUserName(principal.getName());

		user.setProfile(user.getProfile() != null ? user.getProfile() : loggedInUser.getProfile());
		user.setId(loggedInUser.getId()); // Ensure user ID is set correctly

		// Pre-populate email and role for display (unchangeable)
		user.setEmail(loggedInUser.getEmail());
		user.setRole(loggedInUser.getRole());
		user.setEnable(true);

		// Validation (optional, add checks for other fields as needed)
		if (result.hasErrors()) {
			// Handle validation errors (e.g., display them on the form)
			return "profile"; // Replace with your profile view name
		}

		// Profile picture handling (if uploaded)
		if (profileImage != null && !profileImage.isEmpty()) {
			try {
				String imageName = generateUniqueFileName(profileImage);
				String imagePath = saveProfileImage(profileImage, imageName);
				user.setProfile(imagePath); // Update profile picture path in user object
			} catch (Exception e) {
				// Handle image upload errors (e.g., display error message)
				model.addAttribute("error", "Error uploading profile picture");
				return "profile";  // Replace with your profile view name
			}
		}

		// Selective update user information based on form fields
		user.setName(user.getName() != null ? user.getName() : loggedInUser.getName()); // Update name if provided, otherwise keep existing value
		user.setPhone(user.getPhone() != null ? user.getPhone() : loggedInUser.getPhone()); // Update phone number if provided, otherwise keep existing value
		user.setDate(loggedInUser.getDate());

		// Check if the password is being updated
		if (user.getPassword() != null && !user.getPassword().isEmpty()) {
			// Encode the new password before saving it
			user.setPassword(passwordEncoder.encode(user.getPassword()));
		} else {
			// Keep the existing password if no new password is provided
			user.setPassword(loggedInUser.getPassword());
		}

		this.userRepo.save(user);

		// Set success message or redirect to profile view with success message
		session.setAttribute("success", "profile-update");
		return "redirect:/profile";  // Replace with your profile view path
	}




	private String generateUniqueFileName(MultipartFile file) {
		String timestamp = String.valueOf(System.currentTimeMillis());
		String extension = Optional.ofNullable(file.getOriginalFilename())
				.filter(name -> name.contains("."))
				.map(name -> name.substring(name.lastIndexOf(".")))
				.orElse(".jpg"); // Default extension if none provided
		return timestamp + extension;
	}

	private String saveProfileImage(MultipartFile file, String imageName) throws Exception {
		String uploadPath = "src/main/resources/static/images/profile_images"; // Adjust path based on your project structure
		File uploadDir = new File(uploadPath);

		if (!uploadDir.exists()) {
			uploadDir.mkdirs();
		}
		Path imagePath = Paths.get(uploadPath, imageName);
		file.transferTo(imagePath);

		// Return the relative path to the saved image
		return "/images/profile_images/" + imageName;
	}



	@GetMapping("/unban-request")
	public String unbanRequestView(Model m) {
		m.addAttribute("title", "Unban Request | Roll Ease Rental");
		m.addAttribute("unbanRequest", new UnbanRequest());
		return "unban";
	}

	// unban request processing logic.

	@PostMapping("/processing-unban-request")
	public String processUnbanRequest(@Valid @ModelAttribute("unbanRequest") UnbanRequest unbanRequest,
			BindingResult result, HttpSession httpSession) {

		if (result.hasErrors()) {
			return "unban";
		}

		boolean flag = false;

		User user = this.userRepo.loadUserByUserName(unbanRequest.getEmail());

		if (user == null) {
			httpSession.setAttribute("status", "user-not-exist");
			return "redirect:/unban-request?emailNotValid";
		}

		if (user.isEnable()) {
			httpSession.setAttribute("status", "user-not-suspend");
			return "redirect:/unban-request?userIsNotBanned";
		}

		this.unbanRequestRepo.save(unbanRequest);
		flag = true;

		String email = unbanRequest.getEmail();
		String message = unbanRequest.getMessage();
		emailService.sendUnbanEmail(unbanRequest.getEmail(),"Unban Request",unbanRequest.getMessage());
		if (flag) {
			httpSession.setAttribute("status", "message-send-successfully");
		}

		return "redirect:/home";
	}

	@GetMapping("/profile")
	public String showProfile(Model m, Principal principal, HttpSession httpSession) {

		if (principal == null) {
			httpSession.setAttribute("status", "not-login");
			return "redirect:/home";
		}

		User user = this.userRepo.loadUserByUserName(principal.getName());

		m.addAttribute("title", user.getName() + " | Roll Ease Rental");
		m.addAttribute("user", user);
		return "profile";
	}

	@PostMapping("/cart/add")
	public ResponseEntity<String> addToCart(@RequestBody List<CartItem> cartData) {
		// ... existing code for retrieving cart data and handling errors
		cartService.addItemsToCart(cartData);
		// Use the service
		return ResponseEntity.ok().body("Items added to cart successfully!");
	}
	@GetMapping("/checkout")
	public String checkOut(Model m, Principal principal, HttpSession httpSession,HttpServletRequest request) {
		List<CartItem> cartItems = (List<CartItem>) httpSession.getAttribute("cart");
		if (principal == null) {
			httpSession.setAttribute("status", "not-login");
			return "redirect:/home";
		}

		int pinCode = new Random().nextInt(999999);

		User user = this.userRepo.loadUserByUserName(principal.getName());


		if (cartItems == null || cartItems.isEmpty()) {
			return "redirect:/cart/empty";
		}

		if (user.getRole().equals("ROLE_SELLER") || user.getRole().equals("ROLE_ADMIN")) {
			httpSession.setAttribute("status",
					user.getRole().equals("ROLE_SELLER") ? "seller-not-allow" : "admin-not-allow");
			return user.getRole().equals("ROLE_SELLER") ? "redirect:/seller/home" : "redirect:/admin/home";
		}

		m.addAttribute("user", user);
		m.addAttribute("pincode", String.format("%06d", pinCode));
		m.addAttribute("cart",cartItems);
		m.addAttribute("title", "Checkout | Wheelchair Waala");

		return "checkout";
	}


	@GetMapping("/showProduct")
	public String productDetail(@RequestParam(name = "product_id", required = false) Integer id, Model m,
			Principal principal) {

		List<Comment> comments = this.commentRepo.getAllComments(id);

		if (principal != null) {
			User user = this.userRepo.loadUserByUserName(principal.getName());
			m.addAttribute("user", user);
		}

		Product product = this.productRepo.getById(id);

		m.addAttribute("comments", comments);
		m.addAttribute("product", product);
		return "show_product";
	}

	@PostMapping("/processingComment")
	public String processComment(HttpSession httpSession,
			@RequestParam(value = "comment", required = false) String comment,
			@RequestParam(name = "user_id", required = false) Integer userId,
			@RequestParam(value = "product_id", required = false) Integer productId) {

		User user = this.userRepo.getById(userId);

		boolean flag = false;

		Comment cmnt = new Comment();

		cmnt.setComment(comment);
		cmnt.setCommentRelatedTo(productId);
		cmnt.setUser(user);
		cmnt.setDate(new Date());

		this.commentRepo.save(cmnt);
		flag = true;

		if (flag) {
			httpSession.setAttribute("status", "commented-successfully");
			return "redirect:/showProduct?product_id=" + productId;
		}

		httpSession.setAttribute("status", "went-wrong");
		return "redirect:/showProduct?product_id=" + productId;
	}

	@PostMapping("/order/processing-order")
	public String processOrder(@RequestParam(value = "user_id", required = false) Integer userId,
							   @RequestParam(value = "pincode", required = false) String pincode,
							   @RequestParam(value = "address", required = false) String address,
							   HttpSession httpSession) {

		List<CartItem> cart = (List<CartItem>) httpSession.getAttribute("cart");
		Boolean flag=true;
		Double price;
		if(userId == null || pincode == null || address == null) {
			System.out.println("Null");
		}

		User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found!"));

		Order order = new Order();
		for (CartItem cartItem : cart) {
			order.setUser(user);
			order.setPincode(pincode);
			order.setAddress(address);
			order.setEmail(user.getEmail());
			order.setUsername(user.getName());

			flag = cartItem.isRent();
			order.setPrice(cartItem.getProductPrice());
			Optional<Product> product = productRepo.findById(cartItem.getProductId());
			order.setProductId(product.get().getId());
			order.setProductName(product.get().getName());

			// **Validation Check**
			if (order.getProductId() == null) {
				httpSession.setAttribute("orderStatus", "Order failed! Missing product ID.");
				return "redirect:/confirmation"; // Redirect with error message
			}
			// Persist Order to Database
			try {
				orderRepo.save(order);
				httpSession.setAttribute("orderStatus", "Order placed successfully!");
			} catch (DataIntegrityViolationException e) {
				// Handle potential duplicate order or other database constraint violations
				httpSession.setAttribute("orderStatus", "Order failed! Duplicate order or invalid data.");
				e.printStackTrace(); // Log the exception for debugging
			} catch (Exception e) {
				// Handle any other unexpected exceptions
				httpSession.setAttribute("orderStatus", "Order failed! An unexpected error occurred.");
				e.printStackTrace(); // Log the exception for debugging
			}
		}
		if(flag == true){
			emailService.sendEmail(order.getEmail(),"Order Confirmation","\n" +
					"Dear " +user.getName()+",\n"+
					"\n" +
					"Thank you for your order!\n" +
					"\n" +
					"We're excited to let you know that your order "+order.getPincode()+ " was successfully placed on "+ LocalDate.now() +" and is now being processed. Here are the details of your order:\n" +
					"\n" +
					"Order Summary:\n" +
					"\n" +
					"Items: \n"+ cart + "\n"+
					"Price: "+order.getPrice()+"\n"+
					"Payment Method: 042385303249123 Meezan Bank\n" +
					"Shipping Information: \n"+
					"\n" +
					"Address: " + order.getAddress() + "\n"+
					"We will send you another email once your items are on their way. You can expect delivery in 3 to 4 business days.\n" +
					"\n" +
					"If you have any questions or need to make changes to your order, please contact us at customerservice@rolleaserental.com.\n" +
					"\n" +
					"Thank you for choosing Roll Ease Rental!\n" +
					"\n" +
					"Best regards,\n" +
					"Roll Ease Rental Customer Service Team");
		}
		else{
			Integer depositAmount = 10000;
			emailService.sendEmail(order.getEmail(),"Order Confirmation","\n" +
					"Dear " + user.getName() + ",\n\n" +
					"Thank you for your order to rent a wheelchair from Roll Ease Rental!\n\n" +

					"**Important Information Regarding Order Confirmation:**\n\n" +
					"To confirm your order for renting a wheelchair, a security deposit of Rs. " + depositAmount + " needs to be paid **in addition to** the monthly rent of " +order.getPrice() + ".\n\n" +

					"**Payment Instructions:**\n\n" +
					"Please deposit the total amount (security deposit + monthly rent) to the following Meezan Bank account:\n\n" +
					"Account Name: Roll Ease Rental\n" +
					"Account Number: 042385303249123\n\n" +

					"**Order Confirmation:**\n\n" +
					"Once your deposit and rent payment are verified, your order (reference number: " + order.getPincode() + ") will be confirmed, and you will receive a separate email notification. \n\n" +

					"**Delivery:**\n\n" +
					"You can expect delivery within 3 to 4 business days after your order confirmation.\n\n" +

					"**Questions or Changes:**\n\n" +
					"If you have any questions or need to make changes to your order, please contact us at customerservice@rolleaserental.com.\n\n" +

					"Thank you for choosing Roll Ease Rental!\n\n" +
					"Best regards,\n" +
					"Roll Ease Rental Customer Service Team");

		}

		// Redirect to Confirmation Page
		httpSession.setAttribute("status", "order-added");
		return "redirect:/home";
	}

	@GetMapping("/customer/orders")
	public String getCustomerOrders(Principal principal, Model model) {
		String email = principal.getName();
		User user = userRepo.findByEmail(email);

		List<Order> orders = orderRepo.findByUserId(user.getId());

		model.addAttribute("orders", orders);
		System.out.println("Retrieved Orders: " + orders);
		return "orderpage"; // The name of your Thymeleaf template for the orders page
	}
}
