package com.rolleaserental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreWalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
